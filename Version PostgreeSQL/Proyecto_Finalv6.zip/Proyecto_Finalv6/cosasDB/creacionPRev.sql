CREATE DATABASE sistema_documentos
WITH 
    OWNER = lolcito
    ENCODING = 'UTF8'
    LC_COLLATE = 'C'
    LC_CTYPE = 'C'
    TEMPLATE = template0;


ALTER USER lolcito SET client_encoding TO 'utf8';